import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as lng
import scipy.io as io
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, AdaBoostClassifier
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from tabulate import tabulate
from sklearn.model_selection import GridSearchCV

#####################
# WARNING THIS SCRIPT TAKES A WHILE TIME TO RUN
#####################



data = io.loadmat('zipdata.mat')

X = data['X']
y = data['y'].ravel()
N, P = X.shape
# --------------- Ex 4 --------------- #
# Try to experiment with criterion, number of estimators, max_depth, min_samples_leaf
clf = RandomForestClassifier(bootstrap=True, oob_score=True, criterion = 'gini',random_state=0, max_depth=10)
# number of trees
n_estimators = [int(x) for x in np.linspace(100, 500, 2)]
# Try to add more of the parameters from the model and then add them to this dict to see how it affects the model.
param_grid = {
    'n_estimators': n_estimators,
}

rf_grid = GridSearchCV(estimator = clf, param_grid = param_grid, cv = 5, verbose=2, iid=True, n_jobs=-1)

# Fit the grid search model
rf_grid.fit(X, y)

## Look at one random forrest and the importance of the features
one_rf = RandomForestClassifier(bootstrap=True, oob_score=True, max_depth = 10, n_estimators=100, criterion = 'gini',random_state=0)
score = one_rf.fit(X, y)
headers = ["name", "score"]
values = sorted(zip(range(0,P), one_rf.feature_importances_), key=lambda x: x[1] * -1)
# See which features are deemed most important by the classifier
print(tabulate(values, headers, tablefmt="plain"))
print ('Random Forest OOB error rate: {}'.format(1 - one_rf.oob_score_))

# --------------- Ex 5 --------------- #
# Try to experiment with max_samples, max_features, number of modles, and other models
#bagging = BaggingClassifier(DecisionTreeClassifier(),n_estimators=100, bootstrap=True, oob_score = True,  max_samples=0.5, max_features=0.5)
bagging = BaggingClassifier(DecisionTreeClassifier(), bootstrap=True, oob_score = True,  max_samples=0.5, max_features=0.5)

param_grid = {
    'n_estimators': n_estimators,
}
bagging_grid = GridSearchCV(estimator = bagging, param_grid = param_grid, cv = 5, verbose=2, iid=True, n_jobs=-1)

# Fit the grid search model
bagging_grid.fit(X, y)

# --------------- Ex 6 --------------- #
# Try to change the learning rate and add it to param_grid
# Create and fit an AdaBoosted decision tree
boost = AdaBoostClassifier(DecisionTreeClassifier(max_depth=1),
                         learning_rate=1.0)

learning_rate = [float(x) for x in np.linspace(0.01, 1.0, 5)]                         
param_grid = {
    'n_estimators': n_estimators
}
boost_grid = GridSearchCV(estimator = boost, param_grid = param_grid, cv = 5, verbose=2, iid=True, n_jobs=-1)

# Fit the grid search model
boost_grid.fit(X, y)

# --------------- Plots --------------- #
rf_scores = rf_grid.cv_results_['mean_test_score']
bagging_score = bagging_grid.cv_results_['mean_test_score']
boost_score = boost_grid.cv_results_['mean_test_score']


plt.figure()
plt.plot(n_estimators, rf_scores, label='Random Forest')
plt.plot(n_estimators, bagging_score, label='Bagging')
plt.plot(n_estimators, boost_score, label='Boosting')
plt.legend()
plt.xlabel('n_estimators')
plt.ylabel('Mean accuracy')
plt.show()


# Lets try and search for the optimal of two parameters for boosting
boost = AdaBoostClassifier(DecisionTreeClassifier(max_depth=1))
learning_rate = [float(x) for x in np.linspace(0.01, 1.0, 5)]                         
param_grid = {
    'n_estimators': n_estimators,
    'learning_rate': learning_rate
}

boost_grid = GridSearchCV(estimator = boost, param_grid = param_grid, cv = 5, verbose=2, iid=True, n_jobs=-1)

# Fit the grid search model
boost_grid.fit(X, y)

boost_score = boost_grid.cv_results_['mean_test_score'].reshape(len(learning_rate),
                                                     len(n_estimators))

plt.figure()
for ind, i in enumerate(learning_rate):
    plt.plot(n_estimators, boost_score[ind], label='Learning Rate: {0:.2f}'.format(i))
plt.legend()
plt.xlabel('n_estimators')
plt.ylabel('Mean accuracy')
plt.show()

