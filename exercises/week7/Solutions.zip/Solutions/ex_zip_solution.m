close all, clear

% load the zip data
load zipdata

% Compute random forest solution
B = 100; % The number of trees in the forest
% 'NVArToSample' is the number of candidate variables to be sampled at each
% split
% 'MinLeaf' gives the tree size (the minimum number of observations in a
% leaf node of any given tree)
%
% To run bagging you set 'NVarToSample' to p
% To run CART you set 'NVarToSample' to p and B = 1 (only one tree)
%
rf1 = TreeBagger(B,X,y,'OOBVarImp','on','Method','classification','NVarToSample',80,'MinLeaf',5);
figure(1); % plot the OOB error for the computed random forest as a function of the number of trees
h1 = plot(1:B,oobError(rf1),'r'); hold on
xlabel('Number of grown trees')
ylabel('Out-of-bag classification error')
title('OOB error for random forests')

% Compute and plot random forests with different parameters
rf2 = TreeBagger(B,X,y,'OOBVarImp','on','Method','classification','NVarToSample',80,'MinLeaf',20);
h2 = plot(1:B,oobError(rf2),'b');
rf3 = TreeBagger(B,X,y,'OOBVarImp','on','Method','classification','NVarToSample',10,'MinLeaf',5);
h3 = plot(1:B,oobError(rf3),'k');

% add legend to plot
legend([h1,h2,h3],{'RF,NVTS-80,ML-5','RF,NVTS-80,ML-20','RF,NVTS-10,ML-5'})

figure(2); % plot the variable importance for one of the random forest calculated above
vi = rf1.OOBPermutedVarDeltaError;
stem(vi)
xlabel('Variable number')
ylabel('Permuted Variables Delta Error')
title('Variable importance for Random Forests')


% Compute Boosting solution
B = 100; % number of models to use in the boosting algorithm
t1 = ClassificationTree.template('MinLeaf',5,'Prune','on'); % decide on tree model to use
ens1 = fitensemble(X,y,'AdaBoostM2',B,t1,'crossval','on','LearnRate',1);
% plot the average k-fold cross validation error as a function of the
% number of models
figure(3);
h1 = plot(1:B,kfoldLoss(ens1,'mode','cumulative'),'k'); hold on

% Compute a boosting solution with a diffferent learnign rate and plot teh
% k-fold CV error
t2 = ClassificationTree.template('MinLeaf',5,'Prune','on');  % decide on tree model to use
ens2 = fitensemble(X,y,'AdaBoostM2',B,t2,'crossval','on','LearnRate',.1);
h2 = plot(1:B,kfoldLoss(ens2,'mode','cumulative'),'r'); hold on

% Compute a bagging solution and plot the k-fold CV error
t3 = ClassificationTree.template('MinLeaf',5,'Prune','on');  % decide on tree model to use
ens3 = fitensemble(X,y,'Bag',B,t3,'type','classification','crossval','on'); 
h3 = plot(1:B,kfoldLoss(ens3,'mode','cumulative'),'b');

legend([h1,h2,h3],{'AdaBoost-LR(1)','AdaBoost-LR(0.1)','Bagging'})
ylabel('Cross validation error')
xlabel('Number of trees')
title('Boosting and Bagging k-fold CV error')

