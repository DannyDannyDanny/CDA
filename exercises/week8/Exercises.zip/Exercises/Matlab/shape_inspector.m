function varargout = shape_inspector(varargin)
% SHAPE_INSPECTOR M-file for shape_inspector.fig
%      SHAPE_INSPECTOR, by itself, creates a new SHAPE_INSPECTOR or raises the existing
%      singleton*.
%
%      H = SHAPE_INSPECTOR returns the handle to a new SHAPE_INSPECTOR or the handle to
%      the existing singleton*.
%
%      SHAPE_INSPECTOR('CALLBACK',fig,eventData,h,...) calls the local
%      function named CALLBACK in SHAPE_INSPECTOR.M with the given input arguments.
%
%      SHAPE_INSPECTOR('Property','Value',...) creates a new SHAPE_INSPECTOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before shape_inspector_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to shape_inspector_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help shape_inspector

% Last Modified by GUIDE v2.5 21-Jun-2005 16:45:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @shape_inspector_OpeningFcn, ...
                   'gui_OutputFcn',  @shape_inspector_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


function draw(h)

m1 = get(h.mode1,'Value');
m2 = get(h.mode2,'Value');
m3 = get(h.mode3,'Value');
m4 = get(h.mode4,'Value');
m5 = get(h.mode5,'Value');
m6 = get(h.mode6,'Value');

b = [m1*sqrt(h.eval(1)) m2*sqrt(h.eval(2)) m3*sqrt(h.eval(3)) m4*sqrt(h.eval(4)) m5*sqrt(h.eval(5)) m6*sqrt(h.eval(6)) zeros(1, h.K-6)]';
fp = h.m + h.evec*b;

drawshape(fp, h.conlist, '-');
axis equal;
axis(h.axis);
axis off


set(gcf, 'Color', 'White');

% --- Executes just before shape_inspector is made visible.
function shape_inspector_OpeningFcn(fig, eventdata, h, varargin)
% This function has no graph_output args, see OutputFcn.
% fig    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% h    structure with h and user data (see GUIDATA)
% varargin   command line arguments to shape_inspector (see VARARGIN)

h = guidata(fig);

h.evec = varargin{1};
h.eval = varargin{2};
h.m = varargin{3}';
h.conlist = varargin{4};
h.n = varargin{5};
h.p = varargin{6};
h.K = varargin{7};

h.output = fig;

minx = min(h.m(1:h.p/2)); maxx = max(h.m(1:h.p/2));
miny = min(h.m(h.p/2+1:end)); maxy = max(h.m(h.p/2+1:end));
deltax = maxx - minx; deltay = maxy - miny;
h.axis = [minx-0.2*deltax maxx+0.2*deltax miny-0.2*deltay maxy+0.2*deltay];

guidata(fig, h);

draw(h);


% --- Outputs from this function are returned to the command line.
function varargout = shape_inspector_OutputFcn(fig, eventdata, h) 
% varargout  cell array for returning graph_output args (see VARARGOUT);
% fig    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% h    structure with h and user data (see GUIDATA)

% Get default command line graph_output from h structure
varargout{1} = h.output;

function mode1_Callback(fig, eventdata, h)
% Hints: get(fig,'Value') returns position of slider
%        get(fig,'Min') and get(fig,'Max') to determine range of slider

draw(h)

function mode2_Callback(fig, eventdata, h)
% Hints: get(fig,'Value') returns position of slider
%        get(fig,'Min') and get(fig,'Max') to determine range of slider

draw(h)

function mode3_Callback(fig, eventdata, h)
% Hints: get(fig,'Value') returns position of slider
%        get(fig,'Min') and get(fig,'Max') to determine range of slider

draw(h)

function mode4_Callback(fig, eventdata, h)
% Hints: get(fig,'Value') returns position of slider
%        get(fig,'Min') and get(fig,'Max') to determine range of slider

draw(h)

function mode5_Callback(fig, eventdata, h)
% Hints: get(fig,'Value') returns position of slider
%        get(fig,'Min') and get(fig,'Max') to determine range of slider

draw(h)

function mode6_Callback(fig, eventdata, h)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

draw(h)


function reset_button_Callback(fig, eventdata, h)

set(h.mode1,'Value', 0);
set(h.mode2,'Value', 0);
set(h.mode3,'Value', 0);
set(h.mode4,'Value', 0);
set(h.mode5,'Value', 0);
set(h.mode6,'Value', 0);

guidata(fig, h);

draw(h)


function mode1_CreateFcn(fig, eventdata, h)
function mode2_CreateFcn(fig, eventdata, h)
function mode3_CreateFcn(fig, eventdata, h)
function mode4_CreateFcn(fig, eventdata, h)
function mode5_CreateFcn(fig, eventdata, h)
function mode6_CreateFcn(fig, eventdata, h)
