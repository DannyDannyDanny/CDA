function drawshape(shape, conList, col)
% draw a shape defined as [x_1 ... x_p y_1 ... y_p]. The argument conlist
% defines the sub-parts of the shape. It is a k-by-3 matrix where each line
% specifies [start_index end_index open/closed (0/1)]. The row [5 10 1]
% therefore defines a closed subshape starting at index 5 and ending at
% index 10. col defines the linestyle and color of the shape, e.g. 'r-' for
% a red shape drawn using a solid line.

nPoints = length(shape)/2;
if size(shape, 1) == 1
  shape = shape';
end

washold = 1;
if ~ishold
  washold = 0;
end

for subShapeId = 1:size(conList, 1)
  if ~washold && subShapeId > 1
    hold on
  end
  range = conList(subShapeId, 1):conList(subShapeId, 2);
  subShape = [shape(range) shape(range + nPoints)];
  if conList(subShapeId, 3) == 0,
    plot(subShape(:, 1), subShape(:, 2), char(col));
  else
    closedShape = [subShape; subShape(1, :)];
    plot(closedShape(:, 1), closedShape(:, 2), char(col));
  end
end

if ~washold
  hold off
end
