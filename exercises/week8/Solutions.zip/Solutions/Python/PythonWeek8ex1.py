# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 14:36:29 2018

@author: dnor
"""

import numpy as np
import matplotlib.pyplot as plt
from ShapeInspectorGUI import runGUI, allDataC

def drawShape(mu, conlist, ax, color = "b"):
    # Matlabs drawshape is a strange un-intuative function, here's how you do it
    for i in range(np.size(conlist, axis = 0)): # How many different lines exist in the data (7)
        xpoints = mu[conlist[i,0]:conlist[i,1]+1]
        ypoints = mu[conlist[i,0] +  58:conlist[i,1] + 59]
        
        if conlist[i][2] == 1: # If it is a closed loop
            xpoints = np.append(xpoints, xpoints[0]) 
            ypoints = np.append(ypoints, ypoints[0])
        ax.plot(xpoints, ypoints, color = color)
    ax.axis('equal')

dataPath = "C:\\Users\\dnor\\Desktop\\02582\\Lecture6\\M6\\"
X = np.loadtxt(dataPath + "faces.csv", delimiter =",")
conlist = np.loadtxt(dataPath + "conlist.csv", delimiter = ",").astype(int)
# Conlist is stupid and made with "only" matlab in mind, retract 1 to start from 0
conlist[:,0:2] -= 1

n, p = np.shape(X)

mu = np.mean(X, axis = 0)

# center the data
Xc = X - np.ones((n,1))*mu

# Compute PCA as an eigenvalue analysis of the covariance matrix
Eval, Evec = np.linalg.eig(np.cov(X.T))

# Sort while still keeping the imaginary part, therefor lexicographic sorting
# Also, descending sort
sortIndex = np.argsort(Eval)[::-1] 

Eval = Eval[sortIndex].astype(np.float64) # Away with imaginary part (~0) and order
Evec = Evec[:, sortIndex].astype(np.float64)

# Discard strictly none-positive eigenvalues modes
Eval = Eval[np.where(Eval > 1e-9)]
Evec = Evec[:, 0: len(Eval)]

u, d, v = np.linalg.svd(Xc)

# calculate the variances
# keep only modes correspoding to strictly positive singular values
d = d[np.where(d > 1e-9)]
k = len(d)
u = u[:, :k]
v = v[:k, :].T # Matrix that is returned from svd is ordered differently, therefor different slicing

     # Assign PCA
L = v # the loading
S = np.matmul(u, np.diag(d)) # The scores
sigma2 = d ** 2 / n
     
fig, ax = plt.subplots(1,1)
drawShape(mu, conlist, ax)
ax.set_title('Mean face')
plt.show()

# Check if values corrosponds
print("Differences in eigenvalues (variance): %2.3f" % (np.linalg.norm((Eval - d ** 2 / n), ord = 2)))
print("Difference in eigenvalues: %2.3f" % (np.linalg.norm(Evec ** 2 - v ** 2)))

fig, ax = plt.subplots(1,3)
drawShape(mu.T + 2.5 * np.sqrt(sigma2[0]) * L[:, 0], conlist, ax[0], "g")
drawShape(mu.T - 2.5 * np.sqrt(sigma2[0]) * L[:, 0], conlist, ax[0], "r")
drawShape(mu, conlist, ax[0], "b")
ax[0].set_title("First principal axis")

ax[1].matshow(np.abs(np.corrcoef(S, rowvar = False)))
ax[1].set_title("Correlation of scores")

ax[2].matshow(np.abs(np.corrcoef(L, rowvar = False)))
ax[2].set_title("Correlation of Loadings")
