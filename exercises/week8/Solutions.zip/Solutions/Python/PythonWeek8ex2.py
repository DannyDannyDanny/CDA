# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 14:06:35 2018

@author: dnor
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn import preprocessing
from ShapeInspectorGUI import runGUI, allDataC

# DeprecationWarning supression
import warnings
warnings.filterwarnings("ignore")

# Import old exercise, and run - can be skipped if you already have vars in kernel memory
# Remember to chance active directory to the one were it exist, otherwise add it to path as;
'''
import sys
sys.path.append("C:\\stuff\\moreStuff\\juice\\ThereAreMoreSubFolders?\\dirwithfile")
'''
# Use function to import everything
from PythonWeek6ex1 import drawShape
from PythonWeek6GetData import getVarsWeek6

dataPath = "C:\\Users\\dnor\\Desktop\\02582\\Lecture6\\M6\\"
n, p, L, X, conlist, Xc, mu, sigma2, S = getVarsWeek6(dataPath)

""" See https://stackoverflow.com/questions/17628589/perform-varimax-rotation-in-python-using-numpy """
def varimax(Phi, gamma = 1, q = 20, tol = 1e-6):
    from numpy import eye, asarray, dot, sum, diag
    from numpy.linalg import svd
    p,k = Phi.shape
    R = eye(k)
    d=0
    for i in range(q):
        d_old = d
        Lambda = dot(Phi, R)
        u,s,vh = svd(dot(Phi.T,asarray(Lambda)**3 - (gamma/p) * dot(Lambda, diag(diag(dot(Lambda.T,Lambda))))))
        R = dot(u,vh)
        d = sum(s)
        if d/d_old < tol: break
    return dot(Phi, R)

Lthres = L
Lthres[np.where(np.abs(L) < 0.15)] = 0
Sthres = np.matmul(Xc, Lthres)
sigma2thres  = np.var(Sthres, axis = 0)

fig, ax = plt.subplots(1,3)
fig.suptitle("Thresholding", fontsize=14)
drawShape(mu.T + 2.5 * np.sqrt(sigma2thres[0]) * Lthres[:, 0], conlist, ax[0], "g")
drawShape(mu.T - 2.5 * np.sqrt(sigma2thres[0]) * Lthres[:, 0], conlist, ax[0], "r")
drawShape(mu, conlist, ax[0], "b")
ax[0].set_title("Thresholding 1st PCA")

ax[1].matshow(np.abs(np.corrcoef(Sthres, rowvar = False)))
ax[1].set_title("Correlation of scores")

ax[2].matshow(np.abs(np.corrcoef(Lthres, rowvar = False)))
ax[2].set_title("Correlation of Loadings")

allData = allDataC(mu, n, p, 8, sigma2thres, conlist, Lthres)
#runGUI(allData)

""" varimax """
L_varimax = varimax(L[:, :12])
S_varimax = np.matmul(Xc, L_varimax)
sigma2_varimax = np.var(S_varimax, axis = 0)

fig, ax = plt.subplots(1,3)
fig.suptitle("Varimax rotation of components")
drawShape(mu.T + 2.5 * np.sqrt(sigma2_varimax[0]) * L_varimax[:, 0], conlist, ax[0], "g")
drawShape(mu.T - 2.5 * np.sqrt(sigma2_varimax[0]) * L_varimax[:, 0], conlist, ax[0], "r")
drawShape(mu, conlist, ax[0], "b")
ax[0].set_title("Thresholding 1st PCA")

ax[1].matshow(np.abs(np.corrcoef(S_varimax, rowvar = False)))
ax[1].set_title("Correlation of scores")

ax[2].matshow(np.abs(np.corrcoef(L_varimax, rowvar = False)))
ax[2].set_title("Correlation of Loadings")

allData = allDataC(mu, n, p, 8, sigma2_varimax, conlist, L_varimax)
#runGUI(allData)

""" Elastic net to choose components """
k = 12 # estimate first 12 components
L_en = np.zeros((p,k))
ElasticNet = linear_model.ElasticNet(alpha = 0.0001, l1_ratio = 0.1, fit_intercept = False) # Ratio is 0 for only l2 penalty
for i in range(k):
    reg_elastic = ElasticNet.fit(Xc, S[:,i]).coef_
    L_en[:,i] = preprocessing.normalize(reg_elastic, norm = "l2")
    
S_en = np.matmul(Xc, L_en)
sigma2_en = np.var(S_en, axis = 0)

fig, ax = plt.subplots(1,3)
fig.suptitle("Elastic net paramter choosing")
drawShape(mu.T + 2.5 * np.sqrt(sigma2_en[0]) * L_en[:, 0], conlist, ax[0], "g")
drawShape(mu.T - 2.5 * np.sqrt(sigma2_en[0]) * L_en[:, 0], conlist, ax[0], "r")
drawShape(mu, conlist, ax[0], "b")
ax[0].set_title("Thresholding 1st PCA")

ax[1].matshow(np.abs(np.corrcoef(S_en, rowvar = False)))
ax[1].set_title("Correlation of scores")

ax[2].matshow(np.abs(np.corrcoef(L_en, rowvar = False)))
ax[2].set_title("Correlation of Loadings")

# allData = allDataC(mu, n, p, 8, sigma2_en, conlist, L_en)
