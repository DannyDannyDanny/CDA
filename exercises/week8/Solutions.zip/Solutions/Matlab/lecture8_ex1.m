clear; close all; clc;

load faces;

% get the size of the data
[n p] = size(X);

% get the mean face
mu = mean(X);
% plot the mean shape
figure(1)
drawshape(mu, conlist, 'b');
axis equal % make sure the aspect ratio is correct
title('Mean face');

% center the data
Xc = X - ones(n,1)*mu;

% compute PCA as an eigenvalue analysis of the covariance matrix
[Evec Eval] = eig(cov(X));
% eigenvalues are usually sorted in ascending order, change to descending
[Eval idx] = sort(diag(Eval), 'descend');
Evec = Evec(:,idx);
% keep only modes correspoding to strictly positive eigenvalues
Eval = Eval(Eval > 1e-9);
Evec = Evec(:,1:length(Eval));

% compute PCA as an SVD of the centered data matrix
[U D V] = svd(Xc, 'econ');
% calculate the variances
% keep only modes correspoding to strictly positive singular values
d = diag(D);
d = d(d > 1e-9);
k = length(d);
U = U(:,1:k);
D = D(1:k,1:k);
V = V(:,1:k);

% check if they are the same. Eigenvectors have arbitrary sign, therefore,
% square all their values
fprintf('Difference in eigenvalues (variances) is %2.3f.\n', norm(Eval - d.^2/n));
fprintf('Difference in eigenvectors is %2.3f.\n', norm(Evec.^2 - V.^2));

% assign PCA variables
L = V; % the loadings
S = U*D; % the scores
sigma2 = diag(D).^2/n; % the variances

% plot faces along the first principal axis
figure(2)
colormap gray
subplot(131)
plot(0,0,'b',0,0,'g',0,0,'r'); % hack to get the legend right
legend('\mu + 2.5\sigma','\mu - 2.5\sigma','\mu');
hold on; axis equal; 
drawshape(mu' + 2.5*sqrt(sigma2(1))*L(:,1), conlist, 'g');
drawshape(mu' - 2.5*sqrt(sigma2(1))*L(:,1), conlist, 'r');
drawshape(mu,conlist,'b');
title('First principal axis');
subplot(132)
imagesc(abs(corrcoef(S))); axis image;
title('Correlation of scores');
subplot(133)
imagesc(abs(corrcoef(L))); axis image;
title('Correlation of loadings');

% run the face inspector
% shape_inspector(L(:,1:8),  sigma2(1:8), mu, conlist, 37, 116, 8); 

