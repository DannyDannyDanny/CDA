% *** SPARSE PCA ***

lecture6_ex1 % run exercise 1 to get the PCA loadings etc

% *** THRESHOLDING ***

Lthresh = L;
Lthresh(abs(L) < 0.15) = 0;
Sthresh = Xc*Lthresh;
sigma2thresh = var(Sthresh);

figure(3)
colormap gray
subplot(131)
plot(0,0,'b',0,0,'g',0,0,'r'); % hack to get the legend right
legend('\mu + 2.5\sigma','\mu - 2.5\sigma','\mu');
hold on; axis equal; 
drawshape(mu' + 2.5*sqrt(sigma2thresh(1))*Lthresh(:,1), conlist, 'g');
drawshape(mu' - 2.5*sqrt(sigma2thresh(1))*Lthresh(:,1), conlist, 'r');
drawshape(mu,conlist,'b');
title('Thresholding, 1st PA');
subplot(132)
imagesc(abs(corrcoef(Sthresh))); axis image;
title('Correlation of scores');
subplot(133)
imagesc(abs(corrcoef(Lthresh))); axis image;
title('Correlation of loadings');
% shape_inspector(Lthresh(:,1:8),  sigma2thresh(1:8), mu, conlist, 37, 116, 8); 

% *** VARIMAX ***

L_varimax = rotatefactors(L(:,1:12));
S_varimax = Xc*L_varimax;
sigma2_varimax = var(S_varimax);

figure(4)
colormap gray
subplot(131)
plot(0,0,'b',0,0,'g',0,0,'r'); % hack to get the legend right
legend('\mu + 2.5\sigma','\mu - 2.5\sigma','\mu');
hold on; axis equal; 
drawshape(mu' + 2.5*sqrt(sigma2_varimax(1))*L_varimax(:,1), conlist, 'g');
drawshape(mu' - 2.5*sqrt(sigma2_varimax(1))*L_varimax(:,1), conlist, 'r');
drawshape(mu,conlist,'b');
title('Varimax, 1st PA');
subplot(132)
imagesc(abs(corrcoef(S_varimax))); axis image;
title('Correlation of scores');
subplot(133)
imagesc(abs(corrcoef(L_varimax))); axis image;
title('Correlation of loadings');
% shape_inspector(Lthresh(:,1:8),  sigma2thresh(1:8), mu, conlist, 37, 116, 8); 

% *** ELASTIC NET ***

k = 12; % estimate first 12 components
L_en = zeros(p, k);
for i = 1:k
  li_en = elasticnet(Xc, S(:,i), 1e6, -10, 0);
  li_en = li_en/sqrt(li_en'*li_en); % normalize to unit length
  L_en(:,i) = li_en;
end
S_en = Xc*L_en;
sigma2_en = var(S_en);

figure(5)
colormap gray
subplot(131)
plot(0,0,'b',0,0,'g',0,0,'r'); % hack to get the legend right
legend('\mu + 2.5\sigma','\mu - 2.5\sigma','\mu');
hold on; axis equal; 
drawshape(mu' + 2.5*sqrt(sigma2_en(1))*L_en(:,1), conlist, 'g');
drawshape(mu' - 2.5*sqrt(sigma2_en(1))*L_en(:,1), conlist, 'r');
drawshape(mu,conlist,'b');
title('Elastic net, 1st PA');
subplot(132)
imagesc(abs(corrcoef(S_en))); axis image;
title('Correlation of scores');
subplot(133)
imagesc(abs(corrcoef(L_en))); axis image;
title('Correlation of loadings');
% shape_inspector(Lthresh(:,1:8),  sigma2thresh(1:8), mu, conlist, 37, 116, 8); 
