# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 12:23:58 2018

@author: dnor
"""
#%%
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_graphviz

dataPath = r"C:\Users\dnor\Desktop\02582\Lecture8\Lecture 8 CART\Exercises\Data"

T = pd.read_csv(dataPath + "\\Actors.csv", delimiter = ",")
T['Actor'] = pd.Categorical(T['Actor']).codes

dtree=DecisionTreeClassifier()
# Casting response into categorical, as decision trees expects cat response
dtree.fit(T[['Actor', 'Budget']], pd.Categorical(T['IMDb']).codes)

with open("dt.dot", 'w') as f:
    export_graphviz(dtree, out_file=f,
                    feature_names=['Actor', 'Budget'])

"""
http://www.webgraphviz.com for visualizing the created graphs, simply open the
.dot file created in your current root folder, and copy everything into the window
and generate the Graph. Otherwise install Graphwiz locally, and use this to
generate a png.
"""