import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_graphviz, tree
import graphviz
import warnings
warnings.filterwarnings('ignore')

# Read data, see ClevelandHeartData.txt for details

T = pd.read_csv('Data/ClevelandHeartData.csv', sep=';')
X = T.loc[:, T.columns != 'Diagnosis']
# Some of the data is written in a European format, that doesn't work in python
X['Oldpeak'] = pd.Series(X['Oldpeak']).str.replace(',', '.')
X['Ca'] = X['Ca'].replace(np.nan, '', regex=True)
y = np.array(T.loc[:, T.columns == 'Diagnosis'])
Xlabel = np.array(T.columns[:-1])
Nobs = len(T)
Nfeature = len(Xlabel)

# Decision trees in python don't handle NaN values in the same way as in matlab
# This model does not support missing values
# we replace every empty value with the column's mean

categories = ['Age', 'Sex', 'Fbs', 'RestECG', 'Exang', 'Slope', 'Thal']

for cat in categories:
    X[cat] = X[cat].replace(np.nan, np.mean(X[cat]), regex=True)
    
Xcat = X[categories]

XcatAr = np.array(Xcat)

# Build and view a large tree
# Read about options in the DecisionTreeClassifier at 
# http://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html#sklearn.tree.DecisionTreeClassifier

# First

dtree=DecisionTreeClassifier()
# Casting response into categorical, as decision trees expects cat response
dtree.fit(XcatAr, y)

# jupyter notebook displays the graphs automatically
# you need to install graphviz on your computer - the other solution is probably easier

dot_data = export_graphviz(dtree, out_file=None, 
                         feature_names=categories,  
                         class_names='Diagnosis',  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)
#graph <--- to display

# not in a notebook

"""
http://www.webgraphviz.com for visualizing the created graphs, simply open the
.dot file created in your current root folder, and copy everything into the window
and generate the Graph. Otherwise install Graphwiz locally, and use this to
generate a png. 
"""

with open("dt.dot", 'w') as f:
    export_graphviz(dtree, out_file=f,
                    feature_names=categories)

    
# Second, there is no support for direct cross-validation

# Third, there is no support for pruning either at this time ;(