clear all
close all

% Read data, see ClevelandHeartData.txt for details

T        = readtable('../Data/ClevelandHeartData.csv');
y        = T(:,14);
X        = T(:,1:13);
Xlabel   = T.Properties.VariableNames(1:13);
Nobs     = size(X,1);
Nfeature = size(X,2);

% Build and view a large tree
tree = fitctree(X,y,'CategoricalPredictors', [2 3  6 7 9 11 13],...
                    'ResponseName','diagnose',...
                    'PredictorNames',Xlabel,...
                    'MinParent',1,...
                    'MinLeaf',1);
            
view(tree,'mode','graph')
%
% Alt 1, Cross validate MinLeaf parameter
%
maxLeaf = 50;
CVloss = zeros(maxLeaf,1);
for i= 1:10, % Repeat 10 times to reduce variation
    for minleaf = 1:maxLeaf, % Test different MinLeaf values
        CVtree = fitctree(X,y,'CategoricalPredictors', [2 3  6 7 9 11 13],...
                              'ResponseName','diagnose',...
                              'PredictorNames',Xlabel,...
                              'MinParent',1,...
                              'MinLeaf',minleaf,...
                              'CrossVal','on',...
                              'KFold',5);
        CVloss(minleaf) = CVloss(minleaf) + kfoldLoss(CVtree);
    end
end
plot(CVloss)
xlabel('MinLeaf')
ylabel('Cross validated loss')
[~, minleafOpt] = min(CVloss);
% Calculate and view final cross validated tree
CVtree = fitctree(X,y,'CategoricalPredictors', [2 3  6 7 9 11 13],...
                      'ResponseName','diagnose',...
                      'PredictorNames',Xlabel,...
                      'MinParent',1,...
                      'MinLeaf',minleafOpt);              
view(CVtree,'mode','graph')
%
% Alt 2, Cost complexity pruning(?)
%
Tree = fitctree(X,y,'CategoricalPredictors', [2 3  6 7 9 11 13],...
                    'ResponseName','diagnose',...
                    'PredictorNames',Xlabel,...
                    'MinParent',1,...
                    'MinLeaf',1);     
[~,~,~,BestLevel] = cvLoss(Tree,'subtrees','all','treesize','se');  
BestTree = prune(Tree,'level',BestLevel);
view(BestTree,'mode','graph')
                  
                  







