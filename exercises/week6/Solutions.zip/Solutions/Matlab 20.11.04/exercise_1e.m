clear all; 
close all; 
clc;
T = readtable('../Data/Actors.csv');

tree = fitrtree(T,'IMDb','MinParent',1);
view(tree,'mode','graph')

